﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreDapperPagingSortingFilteringDemo.Models
{
    public class DataTableOrder
    {
        public int Column { get; set; }
        public string Dir { get; set; }
    }
}
